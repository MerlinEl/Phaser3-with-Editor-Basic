declare module '@tools/fragments' {
    export const vertex: string;
}
