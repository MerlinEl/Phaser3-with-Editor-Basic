import vertex from './default.vert';
export { vertex };
