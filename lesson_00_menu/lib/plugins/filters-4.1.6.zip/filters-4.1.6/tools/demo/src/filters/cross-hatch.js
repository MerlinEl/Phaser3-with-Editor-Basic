export default function ()
{
    this.addFilter('CrossHatchFilter');
}
